const defaultData = {
  SECRET_KEY: 'nodeJS-mongoDBsecretkey',
  EXPIRES_IN: '30d', // expires in 30 days
  SALT_ROUND: 10,
  JWT_ALGORITHM: 'HS256',
  HOST_EMAIL: 'mail@cbnits.com',
  HOST_EMAIL_PASSWORD: 'w#llcbn1ts',
  OTP_EMAILTEMPLATE_PRIMARY_ID:'',
  SETTING_PRIMARY_ID:"5f5f3b308bbfe621e7b8b98e",
  WEB_URL: 'http://111.93.169.90:7084/',
  DATABASE_URI: 'mongodb://roomanizer:rooman1zer2020@111.93.169.90:27929/?authSource=admin&readPreference=primary&appname=MongoDB%20Compass&ssl=false',
  IMAGE_PATH: '/image/',
  USER_IMAGE_PATH: '/userImage/',
  ROOM_IMAGE_PATH: '/roomImage/',
  AMINITIES_IMAGE_PATH:'/aminitiesImage/',

  // SERVICE_IMAGE_PATH: '/serviceImage/',
  LOGO_IMAGE_PATH: '/logo/',
 // ROOM_IMAGE_PATH: '/roomImage/',
}

export default defaultData;